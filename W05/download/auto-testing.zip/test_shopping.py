from shopping import *


def main():
    # The cart to use in your testing.
    cart = [
        ('2 Gallon Whole Milk', 4.99, 2),
        ('Dozen Doughnuts', 12.99, 4)
    ]

    # The discount amount to use in your testing.
    discount = .10

    # Test the `calculate_item_cost` function and print a success or warning message accordingly:
    # calculate_item_cost(item_price: float, quantity: int = 1) -> float

    # Test the `apply_discount` function and print a success or warning message accordingly:
    # apply_discount(total_cost: float, discount_percentage:  float) -> float

    # Test the `calculate_cart_total` function and print a success or warning message accordingly:
    # calculate_cart_total(cart_items: float, discount: float = 0.0) -> float:


if __name__ == '__main__':
    main()
